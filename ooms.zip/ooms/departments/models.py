from django.db import models
from django.db.models import DateTimeField
from django.contrib.auth import get_user_model
from jsonfield import JSONField
User = get_user_model()


# creating departments model and table with multiple attributes
class Department(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


# creating company model and table with multiple attributes
class Company(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


# Create your models here.
class Form(models.Model):
    deptid = models.ForeignKey('departments.Department', on_delete=models.CASCADE)
    fieldsid = models.CharField(max_length=50)


# creating form_fields model and table with multiple attributes
class FormField(models.Model):
    type = models.CharField(max_length=50)
    label = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    placeholder = models.CharField(max_length=50)

    def __str__(self):
        return self.label


# creating company_dept model and table with multiple attributes
class CompanyDept(models.Model):
    compid = models.ForeignKey('departments.Company', on_delete=models.CASCADE)
    deptid = models.ForeignKey('departments.Department', on_delete=models.CASCADE)


# creating company_dept_user table with multiple attributes
class CompanyDeptUser(models.Model):
    compid = models.ForeignKey('departments.Company', on_delete=models.CASCADE)
    deptid = models.ForeignKey('departments.Department', on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)


class PatchDepartment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    company = models.ForeignKey('departments.Company', on_delete=models.CASCADE)
    department = models.ForeignKey('departments.Department', on_delete=models.CASCADE)


STATUS = (
   ('wip', 'Work in progress'),
   ('done', 'Complete')
)

SSUBMIT = (
   ('approved', 'Approve'),
   ('wip', 'Not approved')
)

# creating works model and table with multiple attributes
class Work(models.Model):
    # title = models.CharField(max_length=50)
    # description = models.TextField()
    # status = models.CharField(choices=STATUS, max_length=50)
    # exdate = models.CharField(max_length=50,null=True, blank=True)
    # remarks = models.CharField(max_length=50)
    # reqno = models.CharField(max_length=50)
    # source = models.CharField(max_length=50)
    # ssubmit = models.CharField(choices=SSUBMIT, max_length=50)
    # fapproval = models.CharField(max_length=50)
    # po_wo = models.CharField(max_length=50)
    # country = models.CharField(max_length=50)
    data = JSONField()
    createdby = models.ForeignKey(User, related_name="user_who_create", on_delete=models.CASCADE, null=True, blank=True)
    createdon = models.CharField(max_length=50,null=True, blank=True)
    updatedby = models.ForeignKey(User, related_name="user_who_update", on_delete=models.CASCADE, null=True, blank=True)
    updatedon = models.CharField(max_length=50,null=True, blank=True)
    compid = models.ForeignKey('departments.Company', on_delete=models.CASCADE)
    deptid = models.ForeignKey('departments.Department', on_delete=models.CASCADE)

    # def __str__(self):
    #     return self.title
