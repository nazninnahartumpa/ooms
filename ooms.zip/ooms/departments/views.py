from django.shortcuts import render, redirect
import datetime
from datetime import datetime
from time import strftime
from .models import Department, CompanyDeptUser, Form, FormField, Work
from django.core import serializers
from django.http import JsonResponse
from django.forms.models import model_to_dict
import json



def dashboard(request):
    all_dept_list = Department.objects.all()
    comdeptuser = CompanyDeptUser.objects.all()
    form = Form.objects.all()
    wdata = Work.objects.all()
    dd = []
    for w in wdata:
    	dd.append(w.data)
    context = { 'all_dept_list':all_dept_list,  
    				'comdeptuser':comdeptuser,
    							  'form':form,
    							  'dd':dd,
    							  'wdata':wdata

    		}
    return render(request, 'departments/dashboard.html', context)




def dash_create(request, f_id):
	if request.method == "POST":
		form = Form.objects.get(id=f_id)
		formfields = []
		sf = form.fieldsid.split(",")
		for f in sf:
			ff = FormField.objects.get(id=f)
			formfields.append(ff)
		context = { 'f':form, 'ff':formfields }
		return render(request, 'departments/create.html', context)
	else:
		return redirect('dashboard')


def dash_create_save(request, f_id):
	if request.method == "POST":
		form = Form.objects.get(id=f_id)
		sf = form.fieldsid.split(",")
		wdata = {}
		for f in sf:
			ff = FormField.objects.get(id=f)
			wdata[ff.label] = request.POST.get(ff.name)
		createdby = request.user.id # Getting userid from the session..
		createdon =  datetime.now().strftime("%Y-%m-%d : %I:%M%p")# Getting date time
		updatedby = '' # Giving upadate by field empty
		updatedon = '' # Giving upadate on field empty
		compid = request.session['comp_id'] # Getting compid from the session
		deptid = form.deptid_id # Getting depertment id from the froms table
		wd = Work(data = wdata, createdby_id = createdby, createdon = createdon, updatedby_id = updatedby, updatedon = updatedon, compid_id = compid, deptid_id = deptid)
		wd.save()
		return redirect('dashboard')


def works_table_create(request, id):
	data = Work.objects.filter(deptid_id=id).all()
	print(data)
	#wdata = serializers.serialize('json', data)
	#context['works'] = wdata
	#return JsonResponse(data=wdata)
	return JsonResponse({'works':model_to_dict(data)}, status=200)

	# return JsonResponse({'works':model_to_dict(data)}, status=200)
		



# -----------------------------I need this later----------------------------------
# def dash_create_save(request, f_id):
# 	if request.method == "POST":
# 		form = Form.objects.get(id=f_id)
# 		title = ''
# 		description = ''
# 		status = ''
# 		exdate = ''
# 		remarks = ''
# 		reqno = ''
# 		source = ''
# 		ssubmit = ''
# 		fapproval = ''
# 		po_wo = ''
# 		country = ''
# 		sf = form.fieldsid.split(",")
# 		for fid in sf:
# 			d = FormField.objects.get(id=fid) #Form fields getting from FormField model filterd by Form model primery key
# 			if d.id == 1:
# 				title = request.POST.get(d.name) # Getting value of the form
# 				if len(title) <=0 :
# 					title = ''
# 			elif d.id == 2:
# 				description = request.POST.get(d.name) # Getting value of the form
# 				if len(description) <=0 :
# 					description = ''
# 			elif d.id == 3:
# 				status = request.POST.get(d.name) # Getting value of the form
# 				if len(status) <=0 :
# 					status = ''
# 			elif d.id == 4:
# 				exdate = request.POST.get(d.name) # Getting value of the form
# 				if len(exdate) <=0 :
# 					exdate = ''
# 				exdate = datetime.now().strftime("%Y-%m-%d : %I:%M%p")
# 			elif d.id == 5:
# 				remarks = request.POST.get(d.name) # Getting value of the form
# 				if len(remarks) <=0 :
# 					remarks = ''
# 			elif d.id == 6:
# 				reqno = request.POST.get(d.name) # Getting value of the form
# 				if len(reqno) <=0 :
# 					reqno = ''
# 			elif d.id == 7:
# 				source = request.POST.get(d.name) # Getting value of the form
# 				if len(source) <=0 :
# 					source = ''
# 			elif d.id == 8:
# 				ssubmit = request.POST.get(d.name) # Getting value of the form
# 				if len(ssubmit) <=0 :
# 					ssubmit = ''
# 			elif d.id == 9:
# 				fapproval = request.POST.get(d.name) # Getting value of the form
# 				if len(fapproval) <=0 :
# 					fapproval = ''
# 			elif d.id == 10:
# 				po_wo = request.POST.get(d.name) # Getting value of the form
# 				if len(po_wo) <=0 :
# 					po_wo = ''
# 			elif d.id == 11:
# 				country = request.POST.get(d.name) # Getting value of the form
# 				if len(country) <=0 :
# 					country = ''
# 			createdby = request.user.id # Getting userid from the session..
# 			createdon =  datetime.now().strftime("%Y-%m-%d : %I:%M%p")# Getting date time
# 			updatedby = '' # Giving upadate by field empty
# 			updatedon = '' # Giving upadate on field empty
# 			compid = request.session['comp_id'] # Getting compid from the session
# 			deptid = form.deptid_id # Getting depertment id from the froms table
# 		wd = Work(title=title, description=description, status=status, exdate=exdate, remarks=remarks, reqno=reqno, source=source, ssubmit=ssubmit, fapproval=fapproval, po_wo=po_wo, country=country, createdby_id = createdby, createdon = createdon, updatedby_id = updatedby, updatedon = updatedon, compid_id = compid, deptid_id = deptid)
# 		wd.save()
# 		return redirect('dashboard')
# 	else:
# 		return redirect('dashboard')


# def dash_table_create(request):
# 	dptid = reguest.GET.get('id', None)
# 	data = Work.objects.get(deptid_id=dptid)
# 	print(data)
# 	return JsonResponse(data)

# -----------------------------I want this later----------------------------------