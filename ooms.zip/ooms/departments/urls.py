from django.urls import path, include
from departments import views

urlpatterns = [

    path('create/<int:f_id>', views.dash_create, name='create'),
    path('save/<int:f_id>', views.dash_create_save, name='save'),
    path('works/<int:id>/', views.works_table_create, name='works'),
]
