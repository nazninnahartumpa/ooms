from django.apps import AppConfig


class DepertmentsConfig(AppConfig):
    name = 'departments'
