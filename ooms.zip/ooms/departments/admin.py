from django.contrib import admin
from .models import Department, Company, Form, FormField, CompanyDept, CompanyDeptUser, PatchDepartment, Work


admin.site.register(Department)
admin.site.register(Company)
admin.site.register(Form)
admin.site.register(FormField)
admin.site.register(CompanyDept)
admin.site.register(CompanyDeptUser)
admin.site.register(PatchDepartment)
admin.site.register(Work)
